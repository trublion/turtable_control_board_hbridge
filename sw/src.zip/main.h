#include "mbed.h"

#define DEBUG

void task_input_update (void);
void task_output_update (void);

#ifdef DEBUG
void task_debug (void);
#endif