#include "main.h"

PwmOut pwm1(PF_0), pwm1_n(PA_12);
DigitalOut myled(LED1);
AnalogIn an_peak_detect(PB_0), an_pot_offset(PB_1);

Ticker ticker_task_inputs, ticker_task_output;

#ifdef DEBUG
Ticker ticker_task_debug;
#endif

Serial pc(USBTX, USBRX); // tx, rx

// Global variables
float peak_detect, offset;

int main() {
    
    // Init
    pwm1.period_us(25);
    pwm1.write(0.5);
    
    pwm1_n.period_us(25);
    pwm1_n.write(0.5);
    
    // Pull-up config test
    //pin_mode(PB_0, PullNone);
    //GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPDR0);
    //GPIOB->PUPDR = (uint32_t)0x00000000;
    
    ticker_task_inputs.attach_us(&task_input_update, 1000);
    ticker_task_output.attach_us(&task_output_update, 1000);
    
    #ifdef DEBUG
    pc.baud(115200);
    ticker_task_debug.attach(&task_debug, 0.1);
    #endif
    
    peak_detect = 0;
    offset = 0;
    
    while(1) {
        
        /*myled = 1; // LED is ON
        wait(0.2); // 200 ms
        myled = 0; // LED is OFF
        wait(1.0); // 1 sec
        */
        
        /*for(float p = 0.0f; p < 1.0f; p += 0.01f) {
            pwm1.write(p);
            wait(0.01);
        }*/

    }
}

void task_input_update (void) {
    peak_detect = an_peak_detect.read();
    offset = an_pot_offset.read();
}
    
void task_output_update (void) {
    peak_detect -= 0.2f;
    peak_detect *= 2.0f;
    peak_detect += offset;
    
    if (peak_detect > 0.97f) {
        peak_detect = 1;
    }
    else if (peak_detect < 0.03f) {
        peak_detect = 0;
    }
    
    pwm1.write(peak_detect);
    pwm1_n.write(1 - peak_detect);
}

#ifdef DEBUG
void task_debug (void) {
    pc.printf("AN : %f\r\n", peak_detect);
}
#endif
